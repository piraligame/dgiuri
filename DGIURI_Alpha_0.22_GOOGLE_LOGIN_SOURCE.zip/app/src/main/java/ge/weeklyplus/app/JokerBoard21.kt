package ge.weeklyplus.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Full 24-row, four-player score sheet in the familiar 0.15 visual arrangement. */
@Composable
fun DiaryJokerBoard21() {
    val ctx=LocalContext.current
    val model=remember{JokerHistory(ctx.applicationContext)}
    val current=model.rounds.size
    val currentCards=model.cardCount ?: 1
    var bids by remember(current){ mutableStateOf(List(4){""}) }
    var taken by remember(current){ mutableStateOf(List(4){""}) }
    var message by remember{mutableStateOf("")}
    var historyVisible by remember{mutableStateOf(false)}
    val score=model.scores
    val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->
        if(uri!=null)runCatching{ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(model.exportJson())}}
            .onSuccess{message="ისტორია შენახულია"}.onFailure{message="ექსპორტის შეცდომა"}
    }
    val import=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null)runCatching{ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use{model.importJson(it.readText())}}
            .onSuccess{message="პარტიები იმპორტირებულია: "+it}.onFailure{message="იმპორტის შეცდომა"}
    }
    val border=MaterialTheme.colorScheme.outlineVariant
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){
        Text("🃏 "+tr("ჯოკერი • ძველი დაფა","Joker • classic board"),fontSize=24.sp,fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            Button(onClick={
                val b=bids.map{it.toIntOrNull() ?: -1};val t=taken.map{it.toIntOrNull() ?: -1}
                message=if(model.add(b,t))"დარიგება შენახულია" else "შეამოწმე ციფრები და აღებულების ჯამი"
            },enabled=current<24,modifier=Modifier.weight(1f)){
                Text(tr("შენახვა","Save")+" · "+(current+1)+"/24",fontSize=11.sp)
            }
            OutlinedButton(onClick={model.undo();message="ბოლო დარიგება დაბრუნდა"},enabled=current>0){
                Text("↶",fontSize=15.sp)
            }
            OutlinedButton(onClick={historyVisible=!historyVisible}){Text("☰",fontSize=15.sp)}
        }
        if(message.isNotBlank())Text(message,fontSize=11.sp,color=MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement=Arrangement.spacedBy(3.dp),verticalAlignment=Alignment.CenterVertically){
            Text("კარტი",modifier=Modifier.width(37.dp),fontSize=10.sp)
            repeat(4){p->
                OutlinedTextField(value=model.names[p],onValueChange={model.name(p,it)},singleLine=true,
                    modifier=Modifier.weight(1f),textStyle=LocalTextStyle.current.copy(fontSize=10.sp),
                    label={Text((p+1).toString(),fontSize=9.sp)})
            }
        }
        Column(Modifier.fillMaxWidth().border(1.dp,border,RoundedCornerShape(8.dp))){
            for(roundIndex in 0 until 24) {
                val saved=model.rounds.getOrNull(roundIndex)
                val cards=JokerRules.cards[roundIndex]
                if(roundIndex in listOf(0,8,12,20)) {
                    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer).padding(5.dp)) {
                        Text(tr("პულკი ","Group ")+(listOf(0,8,12,20).indexOf(roundIndex)+1),fontWeight=FontWeight.Bold,fontSize=12.sp)
                    }
                }
                Row(Modifier.fillMaxWidth().heightIn(min=67.dp).padding(vertical=3.dp),
                    verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(3.dp)){
                    Text(cards.toString(),modifier=Modifier.width(37.dp),textAlign=TextAlign.Center,
                        fontWeight=FontWeight.Bold,fontSize=12.sp)
                    repeat(4){p->
                        Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally,
                            verticalArrangement=Arrangement.spacedBy(2.dp)){
                            if(saved!=null){
                                Row(horizontalArrangement=Arrangement.spacedBy(3.dp)){
                                    Text(saved.bids[p].toString(),fontSize=12.sp,fontWeight=FontWeight.Bold)
                                    Text(" / ",fontSize=10.sp)
                                    Text(saved.taken[p].toString(),fontSize=12.sp,fontWeight=FontWeight.Bold)
                                }
                                val pts=JokerRules.points(cards,saved.bids[p],saved.taken[p])
                                Surface(shape=RoundedCornerShape(5.dp),
                                    color=if(pts<0)Color(0xFFF6D7DC) else MaterialTheme.colorScheme.secondaryContainer){
                                    Text(if(pts>0)"+$pts" else pts.toString(),
                                        modifier=Modifier.fillMaxWidth().padding(vertical=2.dp),
                                        fontSize=10.sp,fontWeight=FontWeight.Bold,
                                        color=if(pts<0)Color(0xFF9A233B) else MaterialTheme.colorScheme.onSecondaryContainer,
                                        textAlign=TextAlign.Center)
                                }
                            } else if(roundIndex==current){
                                Row(horizontalArrangement=Arrangement.spacedBy(2.dp),modifier=Modifier.fillMaxWidth()) {
                                    OutlinedTextField(bids[p],{v->bids=bids.toMutableList().apply{set(p,v.filter(Char::isDigit).take(2))}},
                                        modifier=Modifier.weight(1f),singleLine=true,
                                        textStyle=LocalTextStyle.current.copy(fontSize=11.sp,textAlign=TextAlign.Center),
                                        keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),
                                        placeholder={Text("თ",fontSize=9.sp)})
                                    OutlinedTextField(taken[p],{v->taken=taken.toMutableList().apply{set(p,v.filter(Char::isDigit).take(2))}},
                                        modifier=Modifier.weight(1f),singleLine=true,
                                        textStyle=LocalTextStyle.current.copy(fontSize=11.sp,textAlign=TextAlign.Center),
                                        keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),
                                        placeholder={Text("ა",fontSize=9.sp)})
                                }
                                Text("—",fontSize=10.sp)
                            }else{
                                Text("— / —",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("—",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                HorizontalDivider()
            }
        }
        Surface(color=MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(12.dp)){
            Column(Modifier.fillMaxWidth().padding(10.dp)){
                Text(tr("ჯამური ქულები","Total scores"),fontWeight=FontWeight.Bold)
                Row {
                    repeat(4){p->
                        Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){
                            Text(model.names[p].take(9),fontSize=10.sp,maxLines=1)
                            Text(score.totals[p].toString(),fontSize=17.sp,fontWeight=FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if(historyVisible){
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                OutlinedButton(onClick={export.launch("DGIURI_Joker_Backup.json")},modifier=Modifier.weight(1f)){Text("ექსპორტი",fontSize=11.sp)}
                OutlinedButton(onClick={import.launch(arrayOf("application/json","text/plain"))},modifier=Modifier.weight(1f)){Text("იმპორტი",fontSize=11.sp)}
            }
            model.matches.forEachIndexed {i,m ->
                Text(m.date+"  "+m.players.zip(m.points).joinToString(" • "){it.first+" "+it.second},
                    modifier=Modifier.fillMaxWidth().padding(6.dp),fontSize=11.sp)
                TextButton(onClick={model.remove(i)}){Text("წაშლა",fontSize=10.sp)}
                HorizontalDivider()
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
