package ge.weeklyplus.app

import android.content.Context
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Salted and iterated PIN verifier. Distinct debug package keeps test PIN separate. */
object JournalPin20 {
    private fun prefs(context:Context)=context.getSharedPreferences("weeklyplus_journal_lock20",Context.MODE_PRIVATE)
    fun configured(ctx:Context)=prefs(ctx).contains("pin")
    private fun derive(pin:String,salt:ByteArray):ByteArray {
        val spec=PBEKeySpec(pin.toCharArray(),salt,170000,256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally {spec.clearPassword()}
    }
    fun set(ctx:Context,pin:String):Boolean {
        if(!pin.matches(Regex("[0-9]{4,8}")))return false
        val salt=ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash=derive(pin,salt)
        prefs(ctx).edit().putString("salt",Base64.encodeToString(salt,Base64.NO_WRAP))
            .putString("pin",Base64.encodeToString(hash,Base64.NO_WRAP)).apply()
        return true
    }
    fun verify(ctx:Context,pin:String):Boolean {
        val p=prefs(ctx)
        val salt=p.getString("salt",null)?:return false
        val stored=p.getString("pin",null)?:return false
        return runCatching {
            MessageDigest.isEqual(Base64.decode(stored,Base64.DEFAULT),derive(pin,Base64.decode(salt,Base64.DEFAULT)))
        }.getOrDefault(false)
    }
}

@Composable
fun SecureJournal20(model:DiaryModules15,onBack:()->Unit) {
    val ctx=LocalContext.current
    val host=ctx as? FragmentActivity
    var unlocked by remember { mutableStateOf(false) }
    var setup by remember { mutableStateOf(JournalPin20.configured(ctx)) }
    var pin by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val biometricAvailable=remember(ctx) {
        BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)==BiometricManager.BIOMETRIC_SUCCESS
    }
    val prompt=remember(host) {
        if(host==null)null else BiometricPrompt(host,ContextCompat.getMainExecutor(ctx),object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                unlocked=true;error=""
            }
            override fun onAuthenticationError(code:Int,err:CharSequence) {
                super.onAuthenticationError(code,err)
                error=err.toString()
            }
        })
    }
    if(unlocked) {
        DgiuriJournalPage(model,onBack)
        return
    }
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(15.dp)) {
        TextButton(onClick=onBack) {Text("‹ "+tr("სხვა","Other"))}
        Text("🔒 "+tr("პირადი დღიური","Private journal"),style=MaterialTheme.typography.headlineSmall)
        Text(if(!setup) tr("შექმენი 4–8 ციფრიანი PIN დღიურის დასაცავად.","Create a 4–8 digit PIN to protect journal access.")
             else tr("PIN-ით ან ტელეფონის ბიომეტრიით გახსენი დღიური.","Unlock using your PIN or device biometrics."))
        OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},label={Text(if(setup)"PIN" else tr("ახალი PIN","New PIN"))},
            modifier=Modifier.fillMaxWidth(),visualTransformation=PasswordVisualTransformation(),
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true)
        if(!setup) {
            OutlinedTextField(confirmation,{confirmation=it.filter(Char::isDigit).take(8)},
                label={Text(tr("გაიმეორე PIN","Confirm PIN"))},modifier=Modifier.fillMaxWidth(),
                visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true)
        }
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Button(onClick={
            if(!setup) {
                if(pin!=confirmation||!JournalPin20.set(ctx,pin)) error=tr("PIN უნდა იყოს 4–8 ციფრი და ემთხვეოდეს.","PIN must be 4–8 matching digits.")
                else {setup=true;unlocked=true;error="";pin="";confirmation=""}
            } else if(JournalPin20.verify(ctx,pin)) {unlocked=true;error="";pin=""}
            else {error=tr("PIN არასწორია","Incorrect PIN");pin=""}
        },enabled=pin.length>=4) {Text(if(setup)tr("გახსნა","Unlock") else tr("PIN-ის შენახვა","Set PIN"))}
        if(setup&&biometricAvailable&&prompt!=null) {
            OutlinedButton(onClick={
                val info=BiometricPrompt.PromptInfo.Builder().setTitle(tr("დღიურის გახსნა","Unlock journal"))
                    .setSubtitle(tr("დაადასტურე თითის ანაბეჭდით ან სახით","Confirm your identity"))
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .setNegativeButtonText(tr("PIN-ით შესვლა","Use PIN")).build()
                prompt.authenticate(info)
            }) {Text("◉ "+tr("ბიომეტრიით გახსნა","Unlock with biometrics"))}
        }
        Text(tr("დაცვა მოქმედებს ამ აპის დღიურის ეკრანზე. PIN არ დაგავიწყდეს.",
            "This gate protects this app's journal screen. Keep your PIN safe."),style=MaterialTheme.typography.bodySmall)
    }
}
