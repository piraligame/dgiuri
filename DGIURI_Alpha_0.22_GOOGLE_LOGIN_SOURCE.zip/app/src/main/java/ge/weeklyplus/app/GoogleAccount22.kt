package ge.weeklyplus.app

import android.content.Context
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.launch

/** Native Google OAuth -> Firebase. Never writes local or remote records during sign-in. */
object GoogleAuth22 {
    const val WEB_CLIENT_ID="657081408131-10f7g7uepoqcciohkua06lfh2dv3rn4s.apps.googleusercontent.com"
    fun initialize(context: Context) {
        if(FirebaseApp.getApps(context).isNotEmpty())return
        val options=FirebaseOptions.Builder()
            .setApplicationId(if(context.packageName.endsWith(".test"))
                "1:657081408131:android:e2e1eb870827e98c5119b6"
                else "1:657081408131:android:8981a4d964a777ec5119b6")
            .setApiKey("AIzaSyDzXVQgNvLvdaMWgCl8Jo5AZdQlq4B1a20")
            .setProjectId("dgiuri-weeklyplus-ge-2026")
            .setGcmSenderId("657081408131")
            .build()
        FirebaseApp.initializeApp(context,options)
    }
}

@Composable
fun GoogleAccountPanel22() {
    val ctx=LocalContext.current
    val host=ctx as? ComponentActivity
    val auth=remember {GoogleAuth22.initialize(ctx.applicationContext);FirebaseAuth.getInstance()}
    val scope=rememberCoroutineScope()
    var user by remember {mutableStateOf(auth.currentUser)}
    var busy by remember {mutableStateOf(false)}
    var status by remember {mutableStateOf("")}
    var cloudSummary by remember {mutableStateOf("")}
    DisposableEffect(auth){
        val listener=FirebaseAuth.AuthStateListener{user=it.currentUser}
        auth.addAuthStateListener(listener)
        onDispose{auth.removeAuthStateListener(listener)}
    }
    Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
        Text(tr("Google ანგარიში","Google account"),style=MaterialTheme.typography.titleMedium)
        if(user==null){
            Text(tr("Google-ით შესვლა პირდაპირ აპში","Sign in directly in the app"))
            Button(enabled=!busy&&host!=null,onClick={
                val activity=host ?:return@Button
                busy=true;status=tr("გთხოვ, აირჩიე Google ანგარიში","Choose a Google account")
                scope.launch {
                    try {
                        val googleOption=GetSignInWithGoogleOption.Builder(GoogleAuth22.WEB_CLIENT_ID).build()
                        val request=GetCredentialRequest.Builder().addCredentialOption(googleOption).build()
                        val result=CredentialManager.create(activity).getCredential(context=activity,request=request)
                        val cred=result.credential as? CustomCredential ?: error("Unexpected account credential")
                        if(cred.type!=GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL)
                            error("Not a Google ID credential")
                        val token=GoogleIdTokenCredential.createFrom(cred.data).idToken
                        auth.signInWithCredential(GoogleAuthProvider.getCredential(token,null))
                            .addOnSuccessListener {
                                user=auth.currentUser
                                status=tr("Google-ით შესვლა შესრულებულია","Google sign-in complete")
                                busy=false
                            }.addOnFailureListener {err->
                                status=tr("Firebase შეცდომა: ","Firebase error: ")+
                                    (err.localizedMessage?:err.javaClass.simpleName).take(160)
                                busy=false
                            }
                    }catch(err:Exception){
                        status=tr("Google შესვლა ვერ შესრულდა: ","Google sign-in failed: ")+
                            (err.localizedMessage?:err.javaClass.simpleName).take(160)
                        busy=false
                    }
                }
            }) {Text(tr("Google-ით შესვლა","Sign in with Google"))}
        }else{
            Text("✓ "+tr("შესულია: ","Signed in: ")+(user?.email?:user?.displayName?:"Google"),
                color=MaterialTheme.colorScheme.primary)
            OutlinedButton(enabled=!busy,onClick={
                val uid=user?.uid?:return@OutlinedButton
                busy=true;status=tr("ღრუბლოვანი მონაცემების შემოწმება...","Checking saved cloud data...")
                FirebaseFirestore.getInstance().collection("profiles").document(uid).collection("data")
                    .get(Source.SERVER).addOnSuccessListener {snapshot->
                        val docs=snapshot.documents.associateBy{it.id}
                        val ts=(docs["tasks"]?.get("payload") as? Map<*,*>)?.get("items") as? List<*>
                        val ns=(docs["journal"]?.get("payload") as? Map<*,*>)?.get("items") as? List<*>
                        cloudSummary=tr("ღრუბელშია: ","In cloud: ")+
                            (ts?.size?:0).toString()+tr(" საქმე, "," tasks, ")+
                            (ns?.size?:0).toString()+tr(" ჩანაწერი"," notes")
                        status=tr("მხოლოდ წაკითხვის შემოწმება დასრულდა.","Read-only check complete.")
                        busy=false
                    }.addOnFailureListener {err->
                        status=tr("ღრუბლის შემოწმების შეცდომა: ","Cloud read failed: ")+
                            (err.localizedMessage?:err.javaClass.simpleName).take(160)
                        busy=false
                    }
            }) {Text(tr("ღრუბლოვანი ჩანაწერების შემოწმება","Check saved cloud data"))}
            if(cloudSummary.isNotBlank())Text(cloudSummary)
            OutlinedButton(enabled=!busy,onClick={
                auth.signOut();user=null;cloudSummary=""
                status=tr("გამოსული ხარ. ჩანაწერები შენარჩუნებულია.","Signed out. Entries are kept.")
            }) {Text(tr("Google-დან გამოსვლა","Sign out"))}
        }
        if(status.isNotBlank())Text(status,style=MaterialTheme.typography.bodySmall)
        Text(tr("ანგარიშში შესვლა არ წაშლის ან ჩაანაცვლებს ჩანაწერებს. ეს ვერსია ღრუბლის მონაცემებს მხოლოდ კითხულობს; სრული სინქრონიზაცია ცალკე შესამოწმებელია.",
            "Sign-in never overwrites saved entries. This version reads cloud data only; full sync requires additional safety testing."),
            style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
