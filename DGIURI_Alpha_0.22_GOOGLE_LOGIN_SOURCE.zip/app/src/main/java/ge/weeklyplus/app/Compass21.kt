package ge.weeklyplus.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

@Composable
fun DiaryCompass21(onBack:()->Unit) {
    val ctx=LocalContext.current
    val manager=remember {ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager}
    val sensor=remember {manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)}
    var bearing by remember {mutableFloatStateOf(0f)}
    DisposableEffect(manager,sensor) {
        val listener=object:SensorEventListener {
            override fun onSensorChanged(event:SensorEvent) {
                if(event.sensor.type==Sensor.TYPE_ROTATION_VECTOR){
                    val matrix=FloatArray(9)
                    val orientation=FloatArray(3)
                    SensorManager.getRotationMatrixFromVector(matrix,event.values)
                    SensorManager.getOrientation(matrix,orientation)
                    bearing=((Math.toDegrees(orientation[0].toDouble()).toFloat()+360f)%360f)
                }
            }
            override fun onAccuracyChanged(sensor:Sensor?,accuracy:Int){}
        }
        if(sensor!=null)manager.registerListener(listener,sensor,SensorManager.SENSOR_DELAY_UI)
        onDispose{manager.unregisterListener(listener)}
    }
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(20.dp),
        horizontalAlignment=Alignment.CenterHorizontally) {
        TextButton(onClick=onBack,modifier=Modifier.align(Alignment.Start)){Text("‹ "+tr("სხვა","Other"))}
        Text("🧭 "+tr("კომპასი","Compass"),style=MaterialTheme.typography.headlineSmall)
        if(sensor==null){
            Text(tr("ამ ტელეფონს კომპასის შესაბამისი სენსორი არ აქვს.",
                "This device has no rotation-vector compass sensor."))
        } else {
            Box(Modifier.size(260.dp),contentAlignment=Alignment.Center){
                Canvas(Modifier.fillMaxSize()){
                    val r=size.minDimension/2f-6.dp.toPx()
                    drawCircle(Color(0xFF27886F),radius=r,style=Stroke(width=3.dp.toPx()))
                    drawCircle(Color(0xFF94B5AA),radius=r*0.80f,style=Stroke(width=1.dp.toPx()))
                }
                Text("ჩ",Modifier.align(Alignment.TopCenter).padding(top=10.dp),fontSize=20.sp)
                Text("ს",Modifier.align(Alignment.BottomCenter).padding(bottom=10.dp),fontSize=18.sp)
                Text("ა",Modifier.align(Alignment.CenterEnd).padding(end=8.dp),fontSize=18.sp)
                Text("დ",Modifier.align(Alignment.CenterStart).padding(start=8.dp),fontSize=18.sp)
                Text("▲",Modifier.graphicsLayer{rotationZ=-bearing},fontSize=110.sp,color=Color(0xFFD33D50))
            }
            Text(bearing.toInt().toString()+"°",style=MaterialTheme.typography.headlineMedium)
            Text(tr("ჩრდილოეთის მიმართულება — სენსორის მონაცემებით",
                "Heading relative to magnetic north, from device sensors"),style=MaterialTheme.typography.bodySmall)
            Text(tr("სიზუსტისთვის ტელეფონი რვიანის ფორმით გაამოძრავე.",
                "For calibration move the phone in a figure-eight."),style=MaterialTheme.typography.bodySmall)
        }
    }
}
