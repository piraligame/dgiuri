package ge.weeklyplus.app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts journal text at rest using a device-bound Android Keystore AES-GCM key. */
object JournalCrypto20 {
    private const val ALIAS="weeklyplus_journal_aes20"
    private const val PREFIX="a20:"
    private fun key():SecretKey {
        val store=KeyStore.getInstance("AndroidKeyStore").apply {load(null)}
        (store.getKey(ALIAS,null) as? SecretKey)?.let{return it}
        val generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setKeySize(256)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generator.generateKey()
    }
    fun encrypt(plain:String):String {
        val cipher=Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE,key())
        val ciphertext=cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return PREFIX+Base64.encodeToString(cipher.iv+ciphertext,Base64.NO_WRAP)
    }
    fun decrypt(stored:String):String {
        if(!stored.startsWith(PREFIX))return stored
        val bytes=Base64.decode(stored.removePrefix(PREFIX),Base64.DEFAULT)
        require(bytes.size>=28){"Corrupt journal ciphertext"}
        val cipher=Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,bytes.copyOfRange(0,12)))
        return String(cipher.doFinal(bytes.copyOfRange(12,bytes.size)),Charsets.UTF_8)
    }
}
