package ge.weeklyplus.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.Month
import java.time.format.TextStyle

/** True 12-month calendar with seven day columns, not a month-name-only overview. */
@Composable
fun YearCalendar20(store:PlannerStore,selected:LocalDate,onDate:(LocalDate)->Unit,onView:(String)->Unit) {
    val red=Color(0xFFD1293F)
    Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(2.dp)) {
        (0 until 4).forEach { row ->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp)) {
                (0 until 3).forEach {col ->
                    val month=row*3+col+1
                    val first=LocalDate.of(selected.year,month,1)
                    val days=first.lengthOfMonth()
                    val offset=first.dayOfWeek.value-1
                    val weeks=(offset+days+6)/7
                    Surface(
                        shape=RoundedCornerShape(12.dp),
                        color=MaterialTheme.colorScheme.surface,
                        border=BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant),
                        modifier=Modifier.weight(1f)
                    ) {
                        Column(Modifier.padding(horizontal=2.dp,vertical=3.dp),
                            verticalArrangement=Arrangement.spacedBy(2.dp)) {
                            Text(first.month.getDisplayName(TextStyle.SHORT,DiaryWords.locale()),
                                Modifier.fillMaxWidth().clickable {onDate(first);onView("month")},
                                fontSize=10.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,maxLines=1)
                            Row(Modifier.fillMaxWidth()) {
                                listOf("ო","ს","ო","ხ","პ","შ","კ").forEach { letter ->
                                    Text(letter,Modifier.weight(1f),textAlign=TextAlign.Center,
                                        fontSize=7.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            repeat(weeks) { week ->
                                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(0.dp)) {
                                    repeat(7) { dow ->
                                        val day=week*7+dow-offset+1
                                        Box(Modifier.weight(1f).height(11.dp),contentAlignment=Alignment.Center) {
                                            if(day in 1..days) {
                                                val d=first.withDayOfMonth(day)
                                                val active=store.tasks.any{occurrence(it,d)}
                                                Surface(
                                                    color=if(d==selected)MaterialTheme.colorScheme.primary else Color.Transparent,
                                                    shape=CircleShape,
                                                    border=if(active)BorderStroke(1.3.dp,red) else null,
                                                    modifier=Modifier.fillMaxSize().clickable{onDate(d);onView("day")}
                                                ) {
                                                    Box(contentAlignment=Alignment.Center) {
                                                        Text(day.toString(),fontSize=7.5.sp,
                                                            fontWeight=if(d==selected)FontWeight.Bold else FontWeight.Normal,
                                                            color=if(d==selected)MaterialTheme.colorScheme.onPrimary
                                                                  else if(d.dayOfWeek.value==7)red else MaterialTheme.colorScheme.onSurface,
                                                            maxLines=1)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
