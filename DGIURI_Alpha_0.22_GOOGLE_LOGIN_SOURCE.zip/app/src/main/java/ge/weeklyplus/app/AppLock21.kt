package ge.weeklyplus.app

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

/** PIN protects the entire app when enabled; journaling has an additional secure gate. */
object AppLockSettings21 {
    private fun p(ctx:Context)=ctx.getSharedPreferences("weeklyplus_app_lock21",Context.MODE_PRIVATE)
    fun enabled(ctx:Context)=p(ctx).getBoolean("enabled",false)
    fun biometric(ctx:Context)=p(ctx).getBoolean("biometric",false)
    fun setEnabled(ctx:Context,value:Boolean){
        p(ctx).edit().putBoolean("enabled",value).apply()
        if(!value)setBiometric(ctx,false)
    }
    fun setBiometric(ctx:Context,value:Boolean){p(ctx).edit().putBoolean("biometric",value).apply()}
    fun canBiometric(ctx:Context):Boolean=BiometricManager.from(ctx)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)==BiometricManager.BIOMETRIC_SUCCESS
}

@Composable
fun AppUnlock21(onUnlock:()->Unit) {
    val ctx=LocalContext.current
    val host=ctx as? FragmentActivity
    var pin by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    val biometric=AppLockSettings21.biometric(ctx)&&AppLockSettings21.canBiometric(ctx)
    val prompt=remember(host) {
        if(host==null)null else BiometricPrompt(host,ContextCompat.getMainExecutor(ctx),
            object:BiometricPrompt.AuthenticationCallback(){
                override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result); onUnlock()
                }
                override fun onAuthenticationError(code:Int,detail:CharSequence) {
                    super.onAuthenticationError(code,detail);error=detail.toString()
                }
            })
    }
    Column(Modifier.fillMaxSize().padding(25.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
        Spacer(Modifier.height(32.dp))
        Text("🔒 "+tr("დღიური დაცულია","Diary locked"),style=MaterialTheme.typography.headlineMedium)
        Text(tr("შეიყვანე PIN აპის გასახსნელად","Enter your PIN to open the app"))
        OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},
            modifier=Modifier.fillMaxWidth(),singleLine=true,
            label={Text("PIN")},visualTransformation=PasswordVisualTransformation(),
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))
        if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=pin.length>=4,onClick={
            if(JournalPin20.verify(ctx,pin)){pin="";error="";onUnlock()}
            else{pin="";error=tr("არასწორი PIN","Incorrect PIN")}
        },modifier=Modifier.fillMaxWidth()){Text(tr("აპის გახსნა","Unlock app"))}
        if(biometric&&prompt!=null){
            OutlinedButton(onClick={
                val info=BiometricPrompt.PromptInfo.Builder()
                    .setTitle(tr("დღიურის გახსნა","Unlock Diary"))
                    .setSubtitle(tr("ბიომეტრიული დადასტურება","Biometric verification"))
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .setNegativeButtonText(tr("PIN-ის გამოყენება","Use PIN")).build()
                prompt.authenticate(info)
            },modifier=Modifier.fillMaxWidth()){Text("◉ "+tr("ბიომეტრიით გახსნა","Unlock with biometrics"))}
        }
    }
}

@Composable
fun AppLockSettingsPanel21(onChanged:(Boolean)->Unit) {
    val ctx=LocalContext.current
    var enabled by remember {mutableStateOf(AppLockSettings21.enabled(ctx))}
    var bio by remember {mutableStateOf(AppLockSettings21.biometric(ctx))}
    var pin by remember {mutableStateOf("")}
    var repeated by remember {mutableStateOf("")}
    var status by remember {mutableStateOf("")}
    val configured=JournalPin20.configured(ctx)
    val available=AppLockSettings21.canBiometric(ctx)
    Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
        Text("🔐 "+tr("PIN და ბიომეტრია აპის შესვლისას","App login PIN and biometrics"),
            style=MaterialTheme.typography.titleMedium)
        Text(if(enabled)tr("აპის გახსნისას დაცვა ჩართულია.","App entry lock is on.")
             else tr("ამჟამად აპის შესვლის დაცვა გამორთულია.","App entry lock is currently off."),
             style=MaterialTheme.typography.bodySmall)
        OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},modifier=Modifier.fillMaxWidth(),
            visualTransformation=PasswordVisualTransformation(),singleLine=true,
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),
            label={Text(if(configured)tr("მიმდინარე PIN","Existing PIN") else tr("ახალი PIN (4–8 ციფრი)","New PIN (4–8 digits)"))})
        if(!configured)OutlinedTextField(repeated,{repeated=it.filter(Char::isDigit).take(8)},
            modifier=Modifier.fillMaxWidth(),singleLine=true,visualTransformation=PasswordVisualTransformation(),
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),
            label={Text(tr("გაიმეორე ახალი PIN","Confirm PIN"))})
        Button(enabled=pin.length>=4,onClick={
            if(!enabled){
                val ok=if(configured)JournalPin20.verify(ctx,pin)
                       else pin==repeated && JournalPin20.set(ctx,pin)
                if(ok){
                    AppLockSettings21.setEnabled(ctx,true);enabled=true;pin="";repeated="";
                    status=tr("დაცვა ჩართულია. მომავალ გახსნაზე PIN დაგჭირდება.","Lock enabled for the next launch.")
                    onChanged(true)
                }else status=tr("შეამოწმე PIN და დადასტურება","Check PIN and confirmation")
            } else {
                if(JournalPin20.verify(ctx,pin)){
                    AppLockSettings21.setEnabled(ctx,false);enabled=false;bio=false;pin="";
                    status=tr("აპის შესვლის PIN გამორთულია","App entry lock disabled")
                    onChanged(false)
                }else status=tr("PIN არასწორია","Incorrect PIN")
            }
        },modifier=Modifier.fillMaxWidth()){
            Text(if(enabled)tr("აპის შესვლის PIN-ის გამორთვა","Disable app entry PIN")
                 else tr("აპის შესვლის PIN-ის ჩართვა","Enable app entry PIN"))
        }
        if(enabled){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text(tr("ბიომეტრიით გახსნა","Biometric unlock"))
                Switch(checked=bio,onCheckedChange={
                    if(available){bio=it;AppLockSettings21.setBiometric(ctx,it)}
                },enabled=available)
            }
            if(!available)Text(tr("ამ მოწყობილობაზე ძლიერი ბიომეტრია მიუწვდომელია ან არ არის დაყენებული.",
                    "Strong biometric authentication is not available or enrolled."),
                    style=MaterialTheme.typography.bodySmall)
        }
        if(status.isNotEmpty())Text(status,style=MaterialTheme.typography.bodySmall)
    }
}
