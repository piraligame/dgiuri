package ge.weeklyplus.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import org.json.JSONArray

/** Native launcher widget. This is a real Android AppWidgetProvider, not a WebView mockup. */
class DiaryWidget20 : AppWidgetProvider() {
    override fun onUpdate(context:Context, manager:AppWidgetManager, ids:IntArray) {
        ids.forEach { id -> update(context,manager,id) }
    }
    override fun onReceive(context:Context,intent:Intent) {
        super.onReceive(context,intent)
        if (intent.action==Intent.ACTION_DATE_CHANGED || intent.action==Intent.ACTION_TIMEZONE_CHANGED ||
            intent.action==Intent.ACTION_TIME_CHANGED) refreshAll(context)
    }
    companion object {
        fun refreshAll(context:Context) {
            val mgr=AppWidgetManager.getInstance(context)
            val ids=mgr.getAppWidgetIds(android.content.ComponentName(context,DiaryWidget20::class.java))
            ids.forEach { update(context,mgr,it) }
        }
        private fun active(t:org.json.JSONObject, date:LocalDate):Boolean {
            val first=runCatching {LocalDate.parse(t.optString("date"))}.getOrNull()?:return false
            if(date<first)return false
            return when(t.optString("repeat","none")) {
                "daily"->true
                "weekly"->date.dayOfWeek==first.dayOfWeek
                "monthly"->date.dayOfMonth==first.dayOfMonth
                "yearly"->date.monthValue==first.monthValue&&date.dayOfMonth==first.dayOfMonth
                "biweekly"->ChronoUnit.DAYS.between(first,date)%14L==0L
                "weekdays"->date.dayOfWeek.value<=5
                else->date==first
            }
        }
        private fun update(context:Context,mgr:AppWidgetManager,id:Int) {
            val views=RemoteViews(context.packageName,R.layout.widget_diary20)
            val date=LocalDate.now()
            val tasks=mutableListOf<Triple<String,String,Boolean>>()
            val storage=context.getSharedPreferences("weeklyplus_v1",Context.MODE_PRIVATE)
            runCatching{
                val arr=JSONArray(storage.getString("tasks","[]")?:"[]")
                for(i in 0 until arr.length()){
                    val t=arr.getJSONObject(i)
                    if(!active(t,date))continue
                    val completed=t.optJSONArray("completed")?:JSONArray()
                    var done=false
                    for(c in 0 until completed.length())if(completed.optString(c)==date.toString())done=true
                    tasks+=Triple(t.optString("time",""),t.optString("title",""),done)
                }
            }
            val todo=tasks.sortedBy{it.first.ifBlank{"99:99"}}
            val undones=todo.filter{!it.third}
            views.setTextViewText(R.id.widgetTitle20,"დღიური • "+date.toString())
            views.setTextViewText(R.id.widgetCount20,"${tasks.count{it.third}}/${tasks.size} შესრულებული")
            val text=if(undones.isEmpty())listOf("დღისთვის გასაკეთებელი საქმე არ არის") else
                undones.take(3).map{"• "+(if(it.first.isNotBlank())it.first+"  " else "")+it.second}
            views.setTextViewText(R.id.widgetItems20,text.joinToString("\n"))
            val intent=Intent(context,MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi=PendingIntent.getActivity(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widgetRoot20,pi)
            mgr.updateAppWidget(id,views)
        }
    }
}
