package ge.weeklyplus.app

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Build
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext

@Composable
fun DiaryWidgetPin21(){
    val ctx=LocalContext.current
    val manager=remember{AppWidgetManager.getInstance(ctx)}
    val supported=Build.VERSION.SDK_INT>=26 && manager.isRequestPinAppWidgetSupported
    var note by remember{mutableStateOf("")}
    Text("▤ "+tr("მთავარი ეკრანის ვიჯეტი","Home screen widget"),style=MaterialTheme.typography.titleMedium)
    Text(tr("ვიჯეტზე ჩანს დღევანდელი საქმეები და მათი შესრულების რაოდენობა.",
            "The widget shows today's tasks and completion count."),
        style=MaterialTheme.typography.bodySmall)
    OutlinedButton(enabled=supported,onClick={
        val ok=manager.requestPinAppWidget(ComponentName(ctx,DiaryWidget20::class.java),null,null)
        note=if(ok)tr("ვიჯეტის დამატების მოთხოვნა გაიგზავნა","Launcher widget request sent")
             else tr("Launcher-მა მოთხოვნა არ მიიღო","Launcher did not accept widget request")
    }){Text(tr("ვიჯეტის დამატება მთავარ ეკრანზე","Add widget to home screen"))}
    if(!supported)Text(tr("თუ Launcher-იდან ვერ დაამატებ: ეკრანზე ხანგრძლივად დაჭერა → ვიჯეტები → დღიური.",
        "If automatic pinning is unavailable: long press home screen → Widgets → Diary."),
        style=MaterialTheme.typography.bodySmall)
    if(note.isNotBlank())Text(note,style=MaterialTheme.typography.bodySmall)
}
