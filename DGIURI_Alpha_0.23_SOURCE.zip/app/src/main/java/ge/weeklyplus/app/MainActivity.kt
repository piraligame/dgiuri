package ge.weeklyplus.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private val Pine = Color(0xFF197E65)
private val DarkPine = Color(0xFF173D31)
private val Mint = Color(0xFFE5F4E9)
private val OffWhite = Color(0xFFF8FAF7)
private val Amber = Color(0xFFF1B94D)
private val MaterialShape = RoundedCornerShape(20.dp)
private val ca = Locale.forLanguageTag("ka-GE")
private val en = Locale.ENGLISH

/** Text is tinted by the chosen palette; page surfaces keep their light/dark backgrounds.
 * Use saturated dark ink on white, luminous light ink on black for readable text.
 */
private data class DiaryTextPalette(val ink:Color,val action:Color,val onAction:Color)
private fun diaryTextPalette(name:String,dark:Boolean):DiaryTextPalette {
    val ink = if(dark) when(name) {
        "purple"->Color(0xFFD9BFF7); "blue"->Color(0xFFC0DBFF)
        "rose"->Color(0xFFFFD1E1); "amber"->Color(0xFFFFE0A8)
        "cyan"->Color(0xFFBAF3F2); "slate"->Color(0xFFD6E1F1)
        else->Color(0xFFB8F5D4)
    } else when(name) {
        "purple"->Color(0xFF563877); "blue"->Color(0xFF1B4D83)
        "rose"->Color(0xFF762C49); "amber"->Color(0xFF5D421D)
        "cyan"->Color(0xFF155258); "slate"->Color(0xFF37465C)
        else->Color(0xFF164B38)
    }
    val action = if(dark) ink else when(name) {
        "purple"->Color(0xFF754AA8); "blue"->Color(0xFF235EAA)
        "rose"->Color(0xFF9A3763); "amber"->Color(0xFF775016)
        "cyan"->Color(0xFF116971); "slate"->Color(0xFF465668)
        else->Color(0xFF196C56)
    }
    return DiaryTextPalette(ink,action,if(dark)Color(0xFF101D17) else Color.White)
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.channel(this)
        GoogleAuth22.initialize(applicationContext)
        setContent { WeeklyApp() }
    }
    override fun onResume() {
        super.onResume()
        runCatching { DiaryClockScheduler.restore(this) }
        runCatching { DiaryWidget20.refreshAll(this) }
    }
}

@Composable
private fun WeeklyApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { PlannerStore(context.applicationContext) }
    val modules = remember { DiaryModules15(context.applicationContext) }
    LaunchedEffect(store.onboarded) { if (!store.onboarded) store.finishOnboarding() }
    DiaryWords.code = store.language
    val lang = store.english
    val palette = diaryTextPalette(store.accent,store.dark)
    // Text colours update across all Material screens, not just controls.
    val colors = if (store.dark) darkColorScheme(
        primary=palette.action, onPrimary=palette.onAction,
        secondary=palette.action, onSecondary=palette.onAction,
        onBackground=palette.ink, onSurface=palette.ink, onSurfaceVariant=palette.ink,
        onPrimaryContainer=palette.ink, onSecondaryContainer=palette.ink,
        background=Color(0xFF090D0C), surface=Color(0xFF17211D),
        surfaceVariant=Color(0xFF26362E))
        else lightColorScheme(
        primary=palette.action, onPrimary=palette.onAction,
        secondary=palette.action, onSecondary=palette.onAction,
        onBackground=palette.ink, onSurface=palette.ink, onSurfaceVariant=palette.ink,
        onPrimaryContainer=palette.ink, onSecondaryContainer=palette.ink,
        background=OffWhite, surface=Color.White, surfaceVariant=Mint)
    var page by remember { mutableStateOf("list") }
    var view by remember { mutableStateOf("month") }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var editing by remember { mutableStateOf<PlanTask?>(null) }
    var creating by remember { mutableStateOf(false) }
    
    var appLockEnabled by remember {mutableStateOf(AppLockSettings21.enabled(context))}
    var unlocked by remember {mutableStateOf(false)}
    DisposableEffect(context,appLockEnabled) {
        val owner=context as? androidx.lifecycle.LifecycleOwner
        val observer=androidx.lifecycle.LifecycleEventObserver { _,event ->
            if(event==androidx.lifecycle.Lifecycle.Event.ON_STOP && appLockEnabled) unlocked=false
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose{owner?.lifecycle?.removeObserver(observer)}
    }
    var notice by remember { mutableStateOf("") }
    var categoryFilter by remember { mutableStateOf("all") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notice = if (granted) tr("შეტყობინებები ჩართულია","Notifications enabled") else tr("შეტყობინებებზე ნებართვა არ გაიცა","Notification permission denied")
    }
    fun askPermission() {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else notice = tr("შეტყობინებები ხელმისაწვდომია","Notifications available")
    }
    MaterialTheme(colorScheme = colors, typography = Typography()) {
        if(appLockEnabled && !unlocked) AppUnlock21{unlocked=true}
        else BoxWithConstraints(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            val tablet = false // Stable six-button bottom menu on foldable/mobile.
            Row(Modifier.fillMaxSize()) {
                if (tablet) {
                    NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                        Spacer(Modifier.height(18.dp))
                        NavItems(page, lang) { page = it }
                    }
                    VerticalDivider()
                }
                Scaffold(
                    modifier = Modifier.weight(1f),
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = { if (!tablet) Surface(color=MaterialTheme.colorScheme.surface) {
                        NavItems(page, lang) { page = it }
                    } },
                    snackbarHost = { if (notice.isNotEmpty()) SnackbarHost(hostState = remember { SnackbarHostState() }) }
                ) { insets ->
                    Column(Modifier.fillMaxSize().padding(insets).padding(horizontal = if (tablet) 26.dp else 16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(46.dp).background(Brush.linearGradient(listOf(Color(0xFF126850),Color(0xFF29AB88))), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Text("✓", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(DiaryWords.appName(), style=MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                Text(tr("შენი დღეები, ლამაზად დაგეგმილი","Your days, beautifully planned"), style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("α 0.23 TEST", style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.primary)
                        }
                        if (notice.isNotEmpty()) {
                            Surface(color=MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(12.dp)) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment=Alignment.CenterVertically) {
                                    Text(notice,Modifier.weight(1f), color=MaterialTheme.colorScheme.onSurface, fontSize=12.sp)
                                    Text("✕", Modifier.clickable { notice="" }.padding(5.dp), color=MaterialTheme.colorScheme.onSurface)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        Box(Modifier.weight(1f).widthIn(max=940.dp).fillMaxWidth()) {
                            when(page) {
                                "list" -> DgiuriListPage(modules)
                                "home" -> HomeScreen(store,date,{date=it}, { creating=true }, { editing=it }, { notice=it })
                                "calendar" -> CalendarScreen(store,date,{date=it},view,{view=it},{creating=true},{editing=it},{notice=it})
                                "insights" -> InsightsScreen(store,modules)
                                "other" -> DgiuriOtherPage { page=it }
                                "mydiary" -> SecureJournal20(modules) { page="other" }
                                "joker" -> Column(Modifier.fillMaxSize()) {
                                    TextButton(onClick={page="other"}){Text("‹ "+tr("სხვა","Other"))}
                                    Box(Modifier.weight(1f)){DiaryJokerBoard21()}
                                }
                                "clock" -> Column(Modifier.fillMaxSize()) {
                                    TextButton(onClick={page="other"}){Text("‹ "+tr("სხვა","Other"))}
                                    Box(Modifier.weight(1f)){DiaryClockPage(::askPermission)}
                                }
                                 "compass" -> DiaryCompass21 { page="other" }
                                "settings" -> SettingsScreen(store,::askPermission,{notice=it}) { state -> appLockEnabled=state;unlocked=true }
                            }
                        }
                    }
                }
            }
        }
        if (creating || editing!=null) TaskDialog(store, editing, date, onClose={ creating=false; editing=null }, onInfo={notice=it})
        

    }
}

@Composable
private fun NavItems(current:String, english:Boolean, onChange:(String)->Unit) {
    val tabs = listOf(Triple("list","☑",tr("სია","List")),Triple("home","⌂",tr("დღეს","Today")),
        Triple("calendar","▦",tr("კალენდარი","Calendar")),Triple("insights","▥",tr("შედეგები","Results")),
        Triple("other","⊞",tr("სხვა","Other")),Triple("settings","⚙",tr("პარამეტრები","Settings")))
    // Every item uses exactly one sixth of available width. No horizontal scrolling.
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val compact = maxWidth < 385.dp
        Row(Modifier.fillMaxWidth().padding(horizontal=2.dp)) {
            tabs.forEach { (key,icon,label) ->
                val selected = if(current in listOf("joker","clock","mydiary")) key=="other" else current==key
                val visibleLabel = if (compact && key=="settings") tr("პარამ.","Settings") else label
                Column(
                    modifier=Modifier.weight(1f).heightIn(min=56.dp)
                        .clickable { onChange(key) }
                        .padding(vertical=5.dp,horizontal=1.dp),
                    horizontalAlignment=Alignment.CenterHorizontally,
                    verticalArrangement=Arrangement.Center
                ) {
                    Surface(color=if(selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent, shape=RoundedCornerShape(20.dp)) {
                        Text(icon,Modifier.padding(horizontal=7.dp,vertical=3.dp),fontSize=19.sp,
                            color=if(selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                    Text(visibleLabel,fontSize=if(compact) 8.sp else 9.sp,
                        fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal,
                        textAlign=TextAlign.Center, maxLines=1, overflow=TextOverflow.Ellipsis,
                        color=if(selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun Heading(title:String,subtitle:String="",action:String?=null,onAction:(()->Unit)?=null) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title,fontWeight=FontWeight.Bold,fontSize=23.sp)
            if(subtitle.isNotEmpty()) Text(subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        }
        if(action!=null && onAction!=null) FilledTonalButton(onClick=onAction){Text(action)}
    }
}
@Composable private fun Panel(content:@Composable ColumnScope.()->Unit) {
    Surface(shape=RoundedCornerShape(22.dp),color=MaterialTheme.colorScheme.surface,tonalElevation=1.dp,border=BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant.copy(alpha=.55f)), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
    }
}
@Composable private fun Tag(text:String,highlight:Boolean=false) {
    Surface(color=if(highlight) Mint else MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(10.dp)) { Text(text,Modifier.padding(horizontal=9.dp,vertical=4.dp),color=if(highlight) DarkPine else MaterialTheme.colorScheme.onSurface,fontSize=11.sp) }
}
@Composable
private fun DateStrip(date:LocalDate,onDate:(LocalDate)->Unit,lang:Boolean,mode:String="day") {
    val prev: () -> Unit = { onDate(when(mode) {"week"->date.minusWeeks(1);"month"->date.minusMonths(1);"year"->date.minusYears(1);else->date.minusDays(1)}) }
    val next: () -> Unit = { onDate(when(mode) {"week"->date.plusWeeks(1);"month"->date.plusMonths(1);"year"->date.plusYears(1);else->date.plusDays(1)}) }
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
        TextButton(onClick=prev) { Text("‹",fontSize=25.sp) }
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Text(when(mode) { "year"->date.year.toString(); "month"->date.format(DateTimeFormatter.ofPattern("LLLL yyyy",DiaryWords.locale()));else->date.format(DateTimeFormatter.ofPattern("d MMMM yyyy",DiaryWords.locale())) },fontWeight=FontWeight.Bold,fontSize=17.sp)
            Text(if(mode=="year") tr("12 თვის მიმოხილვა","12-month overview") else date.dayOfWeek.getDisplayName(TextStyle.FULL,DiaryWords.locale()),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        TextButton(onClick=next) { Text("›",fontSize=25.sp) }
        TextButton(onClick={onDate(LocalDate.now())}) { Text(tr("დღეს","Today"),fontSize=11.sp) }
    }
}
@Composable
private fun HomeScreen(store:PlannerStore,date:LocalDate,onDate:(LocalDate)->Unit,onAdd:()->Unit,onEdit:(PlanTask)->Unit,onInfo:(String)->Unit) {
    val lang=store.english
    val today = store.tasks.filter {occurrence(it,date)}.sortedWith(compareBy({if(it.time.isBlank())"99:99" else it.time},{it.title}))
        var filter by remember { mutableStateOf("all") }
    var quickTitle by remember(date) { mutableStateOf("") }
    var hourlyExpanded by rememberSaveable { mutableStateOf(false) }
    var sort by remember { mutableStateOf("time") }
    val overdue = store.tasks.filter { task ->
        task.repeat == "none" && runCatching { LocalDate.parse(task.date).isBefore(LocalDate.now()) }.getOrDefault(false) && !task.completed.contains(task.date)
    }.sortedBy { it.date }
    val shown = today.filter { t ->
        (filter=="all" || (filter=="done" && taskComplete(t,date)) || (filter=="open" && !taskComplete(t,date)))
    }.let { list -> when(sort) {
        "name" -> list.sortedBy { it.title.lowercase(DiaryWords.locale()) }
        "status" -> list.sortedWith(compareBy({taskComplete(it,date)},{it.time.ifBlank { "99:99" }}))
        else -> list
    } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(15.dp)) {
        Heading(tr("ჩემი დღე","My day"),tr("მთავარზე კონცენტრირდი","Focus on what matters"), "＋") { onAdd() }
        DateStrip(date,onDate,lang)
        Surface(shape=RoundedCornerShape(21.dp),color=MaterialTheme.colorScheme.surface,shadowElevation=1.dp,border=BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant.copy(alpha=.7f))) {
            Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value=quickTitle,onValueChange={quickTitle=it},singleLine=true,
                    placeholder={Text(tr("სწრაფად დაამატე საქმე...","Quickly add a task..."),fontSize=12.sp)},
                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(15.dp))
                FilledIconButton(onClick={store.addTask(PlanTask(title=quickTitle.trim(),date=date.toString()));quickTitle=""},enabled=quickTitle.isNotBlank()) {
                    Text("+",fontSize=24.sp)
                }
            }
        }
        if(date==LocalDate.now() && overdue.isNotEmpty()) Panel {
            Text(tr("დაგვიანებული საქმეები","Overdue tasks")+" · ${overdue.size}",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.error)
            overdue.take(4).forEach { t ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.title,maxLines=1,overflow=TextOverflow.Ellipsis,fontSize=13.sp,fontWeight=FontWeight.SemiBold)
                        Text(t.date,fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick={store.updateTask(t.copy(date=date.toString(),completed=t.completed-t.date))}) { Text(tr("დღეს გადმოტანა","Move to today"),fontSize=11.sp) }
                }
            }
        }
        Panel {
            Row(Modifier.fillMaxWidth().clickable { hourlyExpanded = !hourlyExpanded }.padding(vertical=0.dp),
                verticalAlignment=Alignment.CenterVertically) {
                Text(tr("საათობრივი განრიგი","Hourly schedule"),fontWeight=FontWeight.Medium,fontSize=12.sp,modifier=Modifier.weight(1f))
                Text("${today.count {taskComplete(it,date)}}/${today.size}",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)
                Spacer(Modifier.width(12.dp))
                Text(if(hourlyExpanded) "⌃" else "⌄",fontSize=15.sp,color=MaterialTheme.colorScheme.primary)
            }
            if (hourlyExpanded) {
            if(today.isNotEmpty()) {
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text(tr("დალაგება:","Sort:"),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    listOf("time" to tr("დრო","Time"),"name" to tr("სახელი","Name"),"status" to tr("სტატუსი","Status")).forEach { (v,label) ->
                        FilterChip(selected=sort==v,onClick={sort=v},label={Text(label,fontSize=10.sp)})
                    }
                }
                LinearProgressIndicator(progress={today.count {taskComplete(it,date)}.toFloat()/today.size},modifier=Modifier.fillMaxWidth().height(6.dp),color=MaterialTheme.colorScheme.primary,trackColor=Mint)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("all" to (tr("ყველა","All")),"open" to (tr("გასაკეთებელი","To do")),"done" to (tr("შესრულებული","Done"))).forEach { (id,label)->
                        FilterChip(selected=filter==id,onClick={filter=id},label={Text(label,fontSize=11.sp)})
                    }
                }
            }
            if(shown.isEmpty()) {
                Text(if(today.isEmpty()) (tr("ამ დღისთვის საქმე ჯერ არ არის. დაამატე პირველი გეგმა!","No tasks yet. Make your first plan!")) else (tr("ამ ფილტრში საქმე ვერ მოიძებნა","No matches for this filter")),color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp)
            } else shown.forEach { t -> TaskRow(t,date,store,onEdit,onInfo) }
            }
        }
        if(date==LocalDate.now()) {
            val tomorrow=date.plusDays(1)
            val tomorrowCount=store.tasks.count { occurrence(it,tomorrow) && !taskComplete(it,tomorrow) }
            Surface(shape=MaterialShape,color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.65f),modifier=Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal=9.dp,vertical=2.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(tr("ხვალ","Tomorrow")+" · $tomorrowCount ${tr("საქმე","tasks")}",Modifier.weight(1f),fontSize=11.sp,fontWeight=FontWeight.Medium)
                    TextButton(onClick={onDate(tomorrow)},contentPadding=PaddingValues(horizontal=6.dp,vertical=0.dp)){
                        Text(tr("ნახვა","View"),fontSize=11.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun TaskRow(task:PlanTask,date:LocalDate,store:PlannerStore,onEdit:(PlanTask)->Unit,onInfo:(String)->Unit) {
    val done=taskComplete(task,date)
    val rank=task.priorities[date.toString()] ?: 0
    Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically) {
        Checkbox(checked=done,onCheckedChange={store.toggleTask(task,date)},modifier=Modifier.size(40.dp))
        Spacer(Modifier.width(5.dp))
        Column(Modifier.weight(1f).clickable {onEdit(task)},verticalArrangement=Arrangement.spacedBy(3.dp)) {
            Text(task.title,fontWeight=FontWeight.Medium,fontSize=14.sp,color=if(done)MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,maxLines=2)
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp),verticalAlignment=Alignment.CenterVertically) {
                if(task.time.isNotEmpty()) Text(if(task.durationMinutes>0) "${task.time}–${taskTime(task)?.plusMinutes(task.durationMinutes.toLong())?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: task.time}" else task.time,color=MaterialTheme.colorScheme.primary,fontSize=11.sp,fontWeight=FontWeight.Bold)
                Text(tr(task.category,categoryEn(task.category)),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                if(task.repeat!="none") Text("↻",color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
                if(task.reminder>=0) Text("♩",color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
            }
        }
        Text(if(rank>0)"★" else "☆",Modifier.clickable {store.togglePriority(task,date)}.padding(9.dp),color=Amber,fontSize=25.sp)
        Text("✎",Modifier.clickable {onEdit(task)}.padding(7.dp),fontSize=16.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CalendarScreen(store:PlannerStore,date:LocalDate,onDate:(LocalDate)->Unit,view:String,onView:(String)->Unit,onAdd:()->Unit,onEdit:(PlanTask)->Unit,onInfo:(String)->Unit) {
    val lang=store.english
    val selectedTasks=store.tasks.filter {occurrence(it,date)}.sortedBy {it.time}
    Column(Modifier.fillMaxSize().then(if(view=="year")Modifier else Modifier.verticalScroll(rememberScrollState())),verticalArrangement=Arrangement.spacedBy(if(view=="year")5.dp else 14.dp)) {
        Heading(tr("კალენდარი","Calendar"),tr("ნახე დღე, კვირა და თვე","See your plans at a glance"), "＋") {onAdd()}
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("day","week","month","year").forEachIndexed { index,v ->
                SegmentedButton(selected=view==v,onClick={onView(v)},shape=SegmentedButtonDefaults.itemShape(index,4)) {
                    Text(when(v){"day"->tr("დღე","Day");"week"->tr("კვირა","Week");"month"->tr("თვე","Month");else->tr("წელი","Year")},fontSize=11.sp)
                }
            }
        }
        DateStrip(date,onDate,lang,view)
        if(view=="year") {
            YearCalendar20(store,date,onDate,onView)
        } else if(view=="week") {
            val start=date.minusDays((date.dayOfWeek.value-1).toLong())
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp)) {
                (0..6).forEach { i ->
                    val d=start.plusDays(i.toLong())
                    Surface(shape=RoundedCornerShape(12.dp), color=if(d==date)Pine else MaterialTheme.colorScheme.surface,modifier=Modifier.weight(1f).clickable{onDate(d);onView("day")}) {
                        Column(Modifier.padding(vertical=12.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                            Text(d.dayOfWeek.getDisplayName(TextStyle.SHORT,DiaryWords.locale()).take(2),fontSize=10.sp,color=if(d==date)Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                            val hasEntry = store.tasks.any { occurrence(it,d) }
                            Surface(
                                shape=CircleShape,
                                color=Color.Transparent,
                                border=if(hasEntry) BorderStroke(2.dp,Color(0xFFD1293F)) else null
                            ) {
                                Box(Modifier.size(32.dp),contentAlignment=Alignment.Center) {
                                    Text("${d.dayOfMonth}",fontSize=14.sp,fontWeight=FontWeight.Bold,
                                        color=if(d==date) Color.White else MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }
            }
        } else if(view=="month") {
            val start=date.withDayOfMonth(1)
            val first=start.minusDays((start.dayOfWeek.value-1).toLong())
            Panel {
                Row { (1..7).forEach { n->Text(DayOfWeek.of(n).getDisplayName(TextStyle.SHORT,DiaryWords.locale()).take(2),Modifier.weight(1f),textAlign=TextAlign.Center,fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } }
                (0..5).forEach { week ->
                    Row(Modifier.fillMaxWidth()) {
                        (0..6).forEach { dayIndex ->
                            val d=first.plusDays((week*7+dayIndex).toLong())
                            Column(Modifier.weight(1f).clickable {onDate(d);onView("day")}.padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                                val hasEntry = store.tasks.any { occurrence(it,d) }
                                Surface(
                                    color=if(d==date) Pine else Color.Transparent,
                                    shape=CircleShape,
                                    border=if(hasEntry) BorderStroke(2.dp,Color(0xFFD1293F)) else null
                                ) {
                                    Box(Modifier.size(32.dp),contentAlignment=Alignment.Center) {
                                        Text("${d.dayOfMonth}",fontSize=12.sp,fontWeight=FontWeight.Bold,
                                            color=if(d==date) Color.White else if(d.monthValue!=date.monthValue) Color.Gray
                                                else MaterialTheme.colorScheme.onSurface)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if(view!="year") Panel {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(tr("არჩეული დღის საქმეები","Tasks for selected day"),fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                Tag("${selectedTasks.size}",true)
            }
            if(selectedTasks.isEmpty()) Text(tr("საქმეები არ არის","No tasks"),color=MaterialTheme.colorScheme.onSurfaceVariant)
            selectedTasks.forEach {TaskRow(it,date,store,onEdit,onInfo)}
        }
        Spacer(Modifier.height(20.dp))
    }
}


@Composable
private fun YearCalendar(store:PlannerStore,date:LocalDate,onDate:(LocalDate)->Unit,onView:(String)->Unit) {
    Panel {
        Text(tr("წლის კალენდარი","Year calendar"),fontWeight=FontWeight.Bold,fontSize=16.sp)
        (0..3).forEach { row ->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                (1..3).forEach { column ->
                    val month=row*3+column
                    val first=LocalDate.of(date.year,month,1)
                    val days=(1..first.lengthOfMonth()).map { first.withDayOfMonth(it) }
                    val count=store.tasks.count { task -> days.any { occurrence(task,it) } }
                    val selected=date.monthValue==month
                    Surface(shape=RoundedCornerShape(17.dp),border=BorderStroke(1.dp,if(selected) Pine else MaterialTheme.colorScheme.outlineVariant),
                        color=if(selected) Mint else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.50f),
                        modifier=Modifier.weight(1f).clickable { onDate(first); onView("month") }) {
                        Column(Modifier.padding(vertical=13.dp,horizontal=5.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)) {
                            Text(first.month.getDisplayName(TextStyle.SHORT,DiaryWords.locale()),fontSize=12.sp,fontWeight=FontWeight.Bold,color=if(selected) DarkPine else MaterialTheme.colorScheme.onSurface,maxLines=1)
                            Text(if(count>0) "$count ${tr("საქმე","tasks")}" else "—",fontSize=10.sp,color=if(selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GoalsScreen(store:PlannerStore,onAdd:()->Unit,onEditTask:(PlanTask)->Unit) {
    val lang=store.english
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Heading(tr("ჩემი მიზნები","My goals"),tr("დიდი მიზნები პატარა ნაბიჯებით","Big things, small steps"), "＋") {onAdd()}
        if(store.goals.isEmpty()) Panel {
            Text(tr("შექმენი მიზანი და დაუკავშირე დავალებები, რომ პროგრესი დაინახო.","Set a goal and link tasks to it to track your progress."))
        }
        store.goals.forEach { goal ->
            val progress=store.tasks.filter {it.goalId==goal.id}.sumOf {it.completed.size}
            Panel {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text("◎",fontSize=25.sp,color=MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(goal.title,fontWeight=FontWeight.Bold)
                        Text(tr(goal.category,categoryEn(goal.category)),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${progress.coerceAtMost(goal.target)}/${goal.target}",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
                }
                LinearProgressIndicator(progress={progress.toFloat().div(goal.target.coerceAtLeast(1)).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(8.dp),color=MaterialTheme.colorScheme.primary,trackColor=Mint)
                Text("${((progress.toFloat()/goal.target.coerceAtLeast(1))*100).coerceAtMost(100f).toInt()}%",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                var confirm by remember {mutableStateOf(false)}
                TextButton(onClick={confirm=true}){Text(tr("მიზნის წაშლა","Delete goal"))}
                if(confirm) AlertDialog(onDismissRequest={confirm=false},title={Text(tr("წავშალოთ მიზანი?","Delete goal?"))},text={Text(tr("დაკავშირებული დავალებები შენარჩუნდება.","Linked tasks will remain."))},confirmButton={TextButton(onClick={store.deleteGoal(goal.id);confirm=false}){Text(tr("წაშლა","Delete"))}},dismissButton={TextButton(onClick={confirm=false}){Text(tr("გაუქმება","Cancel"))}})
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun InsightsScreen(store:PlannerStore, modules:DiaryModules15) {
    val lang=store.english
    val end=LocalDate.now(); val start=end.minusDays(6)
    val days=(0..6).map {start.plusDays(it.toLong())}
    val total=days.sumOf {date->store.tasks.count {occurrence(it,date)}}
    val done=days.sumOf {date->store.tasks.count {occurrence(it,date)&&taskComplete(it,date)}}
    val ratio=if(total+modules.total==0)0 else (100*(done+modules.done)/(total+modules.total))
    val monthStart=end.withDayOfMonth(1)
    val monthDays=(0 until end.dayOfMonth).map { monthStart.plusDays(it.toLong()) }
    val monthTotal=monthDays.sumOf { d->store.tasks.count {occurrence(it,d)} }
    val monthDone=monthDays.sumOf { d->store.tasks.count {occurrence(it,d)&&taskComplete(it,d)} }
    val streakAnchor=if(store.tasks.any{occurrence(it,end)&&taskComplete(it,end)})end else end.minusDays(1)
    val streak=(0..365).takeWhile { n->val day=streakAnchor.minusDays(n.toLong());store.tasks.any { occurrence(it,day)&&taskComplete(it,day) } }.count()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Heading(tr("ჩემი შედეგები","My results"),tr("ბოლო 7 დღე","Last 7 days"))
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            listOf((tr("შესრულებულია","Completed")) to (done+modules.done).toString(), (tr("შესრულება","Completion")) to "$ratio%").forEach { (label,value)->
                Surface(shape=MaterialShape,color=MaterialTheme.colorScheme.surface,modifier=Modifier.weight(1f)) {
                    Column(Modifier.padding(15.dp)) { Text(value,fontSize=29.sp,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold);Text(label,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            listOf(tr("ამ თვეში","This month") to "$monthDone/$monthTotal",tr("აქტიური დღეები","Day streak") to "$streak").forEach { (label,value)->
                Surface(shape=MaterialShape,color=MaterialTheme.colorScheme.surface,modifier=Modifier.weight(1f)) {
                    Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        Text(value,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary,fontSize=21.sp)
                        Text(label,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Panel {
            Text(tr("დღიური აქტივობა","Daily progress"),fontWeight=FontWeight.Bold)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalAlignment=Alignment.Bottom) {
                days.forEach { day ->
                    val all=store.tasks.count {occurrence(it,day)}
                    val finished=store.tasks.count {occurrence(it,day)&&taskComplete(it,day)}
                    val fraction=if(all==0)0f else finished.toFloat()/all
                    Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally) {
                        Box(Modifier.fillMaxWidth().height(125.dp).background(MaterialTheme.colorScheme.surfaceVariant,RoundedCornerShape(8.dp)),contentAlignment=Alignment.BottomCenter) {
                            Box(Modifier.fillMaxWidth().fillMaxHeight(fraction).background(Pine,RoundedCornerShape(8.dp)))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(day.dayOfWeek.getDisplayName(TextStyle.SHORT,DiaryWords.locale()).take(2),fontSize=10.sp)
                        Text("$finished/$all",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Panel {
            Text(tr("საერთო სია","General list"),fontWeight=FontWeight.Bold)
            Text(modules.done.toString()+"/"+modules.total.toString(),color=MaterialTheme.colorScheme.primary)
        }
        Panel {
            Text(tr("კვირის შეჯამება","Your week"),fontWeight=FontWeight.Bold)
            Text(if(total==0) (tr("დაამატე დავალებები და შედეგებიც აქ გამოჩნდება.","Add tasks to start seeing results.")) else (DiaryWords.weekSummary(done,total)),fontSize=13.sp)
        }
    }
}

@Composable
private fun SettingsScreen(store:PlannerStore,requestPermission:()->Unit,onInfo:(String)->Unit,onAppLockChanged:(Boolean)->Unit) {
    val lang=store.english
    val context=androidx.compose.ui.platform.LocalContext.current
    var pendingBackup by remember { mutableStateOf<String?>(null) }
    val exportLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if(uri!=null) {
            val result=runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(store.exportBackup()) } ?: error("Cannot open file") }
            onInfo(if(result.isSuccess)tr("სარეზერვო ასლი შენახულია","Backup saved") else tr("ასლის შენახვა ვერ მოხერხდა","Backup could not be saved"))
        }
    }
    val importLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null) {
            val result=runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: error("Cannot read file") }
            if(result.isSuccess) pendingBackup=result.getOrNull() else onInfo(tr("ფაილის წაკითხვა ვერ მოხერხდა","Cannot read backup file"))
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Heading(tr("პარამეტრები","Settings"),tr("დღიური შენს გემოზე","Make Diary yours"))
        Panel {
            DiaryThemeDropdown(store)
            HorizontalDivider()
            DiaryLanguageDropdown(store)
        }
        Panel { DgiuriAccentSelector(store) }
        Panel { AppLockSettingsPanel21(onAppLockChanged) }
        Panel { DiaryWidgetPin21() }
        Panel { GoogleAccountPanel22() }
        Panel {
            Text(tr("შეხსენების ნაგულისხმევი რეჟიმი","Reminder defaults"),fontWeight=FontWeight.Bold)
            DiaryReminderMenu(store)
            Text(tr("არსებულ დავალებებს საკუთარი შეხსენების დრო უნარჩუნდება.","Existing tasks keep their own reminders."),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
            FilledTonalButton(onClick=requestPermission) {Text(tr("ტელეფონის შეტყობინებების ჩართვა","Enable phone notifications"))}
            Text(tr("საქმის შეხსენება შეიძლება დაგვიანდეს ენერგოდაზოგვისას; ტაიმერისა და მაღვიძარისთვის ზუსტი დარეკვის ნებართვა ხელმისაწვდომია შესაბამის გვერდებზე.","Task reminders can be delayed by battery saving. Timer and alarm pages can request exact alarm access."),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Panel {
            SettingToggle(tr("ჩუმი საათები","Quiet hours"),store.quietEnabled,store::changeQuietEnabled)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                OutlinedButton(modifier=Modifier.weight(1f),onClick={
                    val parts=store.quietStart.split(":").mapNotNull(String::toIntOrNull)
                    TimePickerDialog(context,{_,h,m->store.setQuiet("%02d:%02d".format(Locale.US,h,m),store.quietEnd)},
                        parts.getOrElse(0){22},parts.getOrElse(1){0},true).show()
                }) {Text(tr("დან ","From ")+store.quietStart+" ✎",fontSize=11.sp)}
                OutlinedButton(modifier=Modifier.weight(1f),onClick={
                    val parts=store.quietEnd.split(":").mapNotNull(String::toIntOrNull)
                    TimePickerDialog(context,{_,h,m->store.setQuiet(store.quietStart,"%02d:%02d".format(Locale.US,h,m))},
                        parts.getOrElse(0){8},parts.getOrElse(1){0},true).show()
                }) {Text(tr("მდე ","To ")+store.quietEnd+" ✎",fontSize=11.sp)}
            }
            Text(tr("ჩუმ საათებში შეხსენება აღარ გაიგზავნება და მოგვიანებით არ გადაინაცვლებს.","Quiet hours suppress, not postpone, reminders."),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Panel { DiaryCommunityLinks() }
        Panel {
            Text(tr("მონაცემები და კონფიდენციალურობა","Data & privacy"),fontWeight=FontWeight.Bold)
            Text(tr("ყველაფერი ტელეფონში ინახება. არ არის ანგარიში, რეკლამები და მომხმარებლის თვალთვალი.","Everything is saved locally on your phone. No account, ads or analytics tracking."),fontSize=13.sp)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick={exportLauncher.launch("DGIURI_backup_${LocalDate.now()}.json")},modifier=Modifier.weight(1f)) { Text(tr("ასლის შენახვა","Export backup"),fontSize=12.sp) }
                OutlinedButton(onClick={importLauncher.launch(arrayOf("application/json","text/plain","application/octet-stream"))},modifier=Modifier.weight(1f)) { Text(tr("ასლის აღდგენა","Import backup"),fontSize=12.sp) }
            }
            Text(tr("ასლის აღდგენა ჩაანაცვლებს ამჟამინდელ საქმეებს; წინასწარ შეინახე სარეზერვო ასლი.","Import replaces your current tasks. Export a backup first."),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(12.dp))
    }
    if(pendingBackup!=null) AlertDialog(onDismissRequest={pendingBackup=null},
        title={Text(tr("აღვადგინოთ სარეზერვო ასლი?","Restore backup?"))},
        text={Text(tr("მიმდინარე ჩანაწერები ჩანაცვლდება. გაგრძელებამდე შეინახე მათი ასლი.","Current entries will be replaced. Back them up first."))},
        confirmButton={Button(onClick={
            val imported=store.importBackup(pendingBackup.orEmpty())
            pendingBackup=null
            onInfo(if(imported)tr("მონაცემები აღდგენილია","Backup restored") else tr("არასწორი ასლის ფაილია","Invalid backup file"))
        }){Text(tr("აღდგენა","Restore"))}},
        dismissButton={TextButton(onClick={pendingBackup=null}){Text(tr("გაუქმება","Cancel"))}})
}

@Composable
private fun DiaryLanguageDropdown(store: PlannerStore) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
        Text(tr("ენა", "Language"), Modifier.weight(1f), fontSize=14.sp)
        Box {
            OutlinedButton(onClick={open=true}, contentPadding=PaddingValues(horizontal=12.dp,vertical=4.dp)) {
                Text(DiaryWords.languageLabel(store.language), fontSize=12.sp, maxLines=1)
                Text(" ▾", fontSize=11.sp)
            }
            DropdownMenu(expanded=open,onDismissRequest={open=false},containerColor=MaterialTheme.colorScheme.surface) {
                DiaryWords.languages.forEach { (code,label) ->
                    DropdownMenuItem(text={Text((if(code==store.language) "✓  " else "     ")+label,color=MaterialTheme.colorScheme.onSurface)},
                        onClick={ store.changeLanguage(code); open=false })
                }
            }
        }
    }
}

@Composable private fun SettingToggle(label:String,value:Boolean,onChange:(Boolean)->Unit) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        Text(label,Modifier.weight(1f),fontSize=14.sp)
        Switch(checked=value,onCheckedChange=onChange)
    }
}
private fun pickTime(context:android.content.Context, initial:String, onSet:(String)->Unit):()->Unit = {
    val parts=initial.split(":").mapNotNull{it.toIntOrNull()}
    TimePickerDialog(context,{_,h,m->onSet("%02d:%02d".format(Locale.US,h,m))},parts.getOrElse(0){9},parts.getOrElse(1){0},true).show()
}
private fun categoryEn(value:String):String = when(value) {"სამუშაო"->"Work";"პირადი"->"Personal";"ჯანმრთელობა"->"Health";"სწავლა"->"Study";"საყიდლები"->"Shopping";else->"Other"}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InlineClock(value:String,onChange:(String)->Unit,onDone:()->Unit,english:Boolean) {
    val hour=value.substringBefore(":").toIntOrNull()?.coerceIn(0,23) ?: 9
    val minute=value.substringAfter(":","00").toIntOrNull()?.coerceIn(0,59) ?: 0
    fun set(h:Int,m:Int) { onChange("%02d:%02d".format(Locale.US,h,m)) }
    Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.surfaceVariant,modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                Text(tr("აირჩიე საათი","Pick an hour"),Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=13.sp)
                TextButton(onClick=onDone) { Text(tr("მზადაა","Done")) }
            }
            (0..3).forEach { r->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp)) {
                    (0..5).forEach { c->val h=r*6+c
                        OutlinedButton(onClick={set(h,minute)},modifier=Modifier.weight(1f).height(36.dp),contentPadding=PaddingValues(0.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=if(hour==h) Pine else MaterialTheme.colorScheme.surface,contentColor=if(hour==h)Color.White else MaterialTheme.colorScheme.onSurface)) {Text("%02d".format(Locale.US,h),fontSize=11.sp)}
                    }
                }
            }
            Text(tr("წუთები","Minutes"),fontSize=12.sp,fontWeight=FontWeight.SemiBold)
            (0..1).forEach { r->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp)) {
                    (0..5).forEach { c->val m=(r*6+c)*5
                        OutlinedButton(onClick={set(hour,m)},modifier=Modifier.weight(1f).height(36.dp),contentPadding=PaddingValues(0.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=if(minute==m) Pine else MaterialTheme.colorScheme.surface,contentColor=if(minute==m)Color.White else MaterialTheme.colorScheme.onSurface)) {Text("%02d".format(Locale.US,m),fontSize=11.sp)}
                    }
                }
            }
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text(tr("ზუსტი წუთი:","Exact minute:"),fontSize=11.sp)
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(value="%02d".format(Locale.US,minute),onValueChange={raw->raw.toIntOrNull()?.takeIf{it in 0..59}?.let{set(hour,it)}},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.width(80.dp))
                Spacer(Modifier.weight(1f))
                Text("%02d:%02d".format(Locale.US,hour,minute),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun TaskDialog(store:PlannerStore, old:PlanTask?, day:LocalDate, onClose:()->Unit,onInfo:(String)->Unit) {
    val context=androidx.compose.ui.platform.LocalContext.current
    val lang=store.english
    val focusManager=LocalFocusManager.current
    val keyboard=LocalSoftwareKeyboardController.current
    var title by remember(old) { mutableStateOf(old?.title ?: "") }
    var date by remember(old) { mutableStateOf(runCatching{LocalDate.parse(old?.date ?: day.toString())}.getOrDefault(day)) }
    var time by remember(old) { mutableStateOf(old?.time ?: "") }
    var showClock by remember(old) { mutableStateOf(false) }
    var duration by remember(old) { mutableIntStateOf(old?.durationMinutes ?: 0) }
    var category by remember(old) { mutableStateOf(old?.category ?: "პირადი") }
    var details by remember(old) { mutableStateOf(old?.details ?: "") }
    var repeat by remember(old) { mutableStateOf(old?.repeat ?: "none") }
    var reminder by remember(old) { mutableIntStateOf(old?.reminder ?: store.reminderDefault) }
    var goalId by remember(old) { mutableStateOf(old?.goalId ?: "") }
    var catMenu by remember {mutableStateOf(false)}
    var repeatMenu by remember {mutableStateOf(false)}
    var reminderMenu by remember {mutableStateOf(false)}
    var goalMenu by remember {mutableStateOf(false)}
    var deleteConfirm by remember {mutableStateOf(false)}
    var error by remember {mutableStateOf("")}
    AlertDialog(
        onDismissRequest=onClose,
        title={Text(if(old==null)(tr("ახალი საქმე","New task")) else (tr("საქმის რედაქტირება","Edit task")))},
        text={Column(Modifier.fillMaxWidth().heightIn(max=530.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(title,{title=it;error=""},label={Text(tr("სათაური","Title"))},singleLine=true,modifier=Modifier.fillMaxWidth())
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick={focusManager.clearFocus();keyboard?.hide();DatePickerDialog(context,{_,y,m,d->date=LocalDate.of(y,m+1,d)},date.year,date.monthValue-1,date.dayOfMonth).show()}){Text("▦ ${date}",fontSize=12.sp)}
                OutlinedButton(onClick={focusManager.clearFocus();keyboard?.hide();showClock=!showClock}){Text("◷ ${time.ifBlank{tr("აირჩიე საათი","Choose time")}}",fontSize=12.sp)}
                if(time.isNotEmpty()) TextButton(onClick={time=""}){Text("✕")}
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf(tr("დღეს","Today") to LocalDate.now(),tr("ხვალ","Tomorrow") to LocalDate.now().plusDays(1),tr("+7 დღე","+7 days") to date.plusDays(7)).forEach { (label,d) ->
                    FilterChip(selected=date==d,onClick={date=d},label={Text(label,fontSize=11.sp)})
                }
            }
            if(showClock) InlineClock(time.ifBlank { "09:00" },{time=it},{showClock=false},lang)
            Text(tr("ხანგრძლივობა (არასავალდებულო)","Duration (optional)"),fontSize=12.sp,fontWeight=FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf(0,15,30,60,90,120).forEach { minutes ->
                    FilterChip(selected=duration==minutes,onClick={duration=minutes},label={Text(DiaryWords.duration(minutes),fontSize=11.sp)})
                }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Box { OutlinedButton(onClick={catMenu=true}){Text(tr(category,categoryEn(category)),fontSize=11.sp)}
                    DropdownMenu(expanded=catMenu,onDismissRequest={catMenu=false}) { TASK_CATEGORIES.forEach { c->DropdownMenuItem(text={Text(tr(c,categoryEn(c)))},onClick={category=c;catMenu=false}) } }
                }
                Box { OutlinedButton(onClick={repeatMenu=true}){Text(when(repeat){"daily"->tr("დღიურად","Daily");"weekly"->tr("კვირაში","Weekly");"monthly"->tr("თვეში","Monthly");"biweekly"->tr("ორ კვირაში","Biweekly");"weekdays"->tr("სამუშაო დღეებში","Weekdays");"yearly"->tr("ყოველწლიურად","Yearly");else->tr("ერთჯერადი","Once")},fontSize=11.sp)}
                    DropdownMenu(expanded=repeatMenu,onDismissRequest={repeatMenu=false}) {listOf("none","daily","weekly","monthly","biweekly","weekdays","yearly").forEach { v ->DropdownMenuItem(text={Text(when(v){"daily"->tr("ყოველდღე","Daily");"weekly"->tr("ყოველკვირა","Weekly");"monthly"->tr("ყოველთვე","Monthly");"biweekly"->tr("ორ კვირაში","Biweekly");"weekdays"->tr("სამუშაო დღეებში","Weekdays");"yearly"->tr("ყოველწლიურად","Yearly");else->tr("ერთჯერადი","Once")})},onClick={repeat=v;repeatMenu=false})} }
                }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Box {OutlinedButton(onClick={reminderMenu=true}){Text(if(reminder<0)(tr("შეხსენების გარეშე","No reminder")) else (DiaryWords.reminderAhead(reminder)),fontSize=11.sp)}
                    DropdownMenu(expanded=reminderMenu,onDismissRequest={reminderMenu=false},containerColor=MaterialTheme.colorScheme.surface) { listOf(-1,0,5,15,30,1440).forEach { m ->DropdownMenuItem(text={Text(when(m){-1->tr("გამორთული","Off");0->tr("დაწყებისას","At start");1440->tr("1 დღით ადრე","1 day before");else->DiaryWords.minutesBefore(m)})},onClick={reminder=m;reminderMenu=false})} }
                }
            }
            OutlinedTextField(details,{details=it},label={Text(tr("შენიშვნა (არასავალდებულო)","Notes (optional)"))},minLines=2,modifier=Modifier.fillMaxWidth())
            if(old!=null) Row(verticalAlignment=Alignment.CenterVertically) {
                TextButton(onClick={
                    store.addTask(old.copy(id=java.util.UUID.randomUUID().toString(),completed=emptySet(),priorities=emptyMap()))
                    onInfo(tr("საქმე დაკოპირებულია","Task duplicated"))
                    onClose()
                }) {Text(tr("დუბლირება","Duplicate"))}
                TextButton(onClick={deleteConfirm=true}) {Text(tr("საქმის წაშლა","Delete task"),color=MaterialTheme.colorScheme.error)}
            }
        }},
        confirmButton={Button(onClick={
            if(title.isBlank()) {error=tr("შეიყვანე სათაური","Enter a title")}
            else if(reminder>=0 && time.isEmpty()) {error=tr("შეხსენებისთვის საათიც აირჩიე","Choose a time for this reminder")}
            else {
                val updated=(old ?: PlanTask(title=title.trim(),date=date.toString())).copy(title=title.trim(),date=date.toString(),time=time,category=category,repeat=repeat,reminder=reminder,details=details,goalId=goalId,durationMinutes=duration)
                if(old==null)store.addTask(updated) else store.updateTask(updated)
                onInfo(tr("საქმე შენახულია","Task saved"));onClose()
            }
        }){Text(tr("შენახვა","Save"))}},
        dismissButton={TextButton(onClick=onClose){Text(tr("გაუქმება","Cancel"))}}
    )
    if(deleteConfirm && old!=null) AlertDialog(onDismissRequest={deleteConfirm=false},title={Text(tr("წავშალოთ საქმე?","Delete task?"))},confirmButton={Button(onClick={store.deleteTask(old.id);deleteConfirm=false;onClose()}){Text(tr("წაშლა","Delete"))}},dismissButton={TextButton(onClick={deleteConfirm=false}){Text(tr("გაუქმება","Cancel"))}})
}
@Composable
private fun GoalDialog(store:PlannerStore,onClose:()->Unit) {
    val lang=store.english
    var name by remember {mutableStateOf("")}
    var target by remember {mutableStateOf("10")}
    var category by remember {mutableStateOf("პირადი")}
    var menu by remember {mutableStateOf(false)}
    AlertDialog(onDismissRequest=onClose,title={Text(tr("ახალი მიზანი","New goal"))},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
        OutlinedTextField(name,{name=it},label={Text(tr("მიზნის სახელი","Goal title"))},singleLine=true)
        OutlinedTextField(target,{target=it.filter{c->c.isDigit()}},label={Text(tr("სამიზნე რაოდენობა","Target count"))},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
        Box { OutlinedButton(onClick={menu=true}){Text(tr(category,categoryEn(category)))}
            DropdownMenu(menu,{menu=false}){TASK_CATEGORIES.forEach{c->DropdownMenuItem(text={Text(tr(c,categoryEn(c)))},onClick={category=c;menu=false})}}
        }
        Text(tr("მიზანს ახალი ან არსებული დავალებები დაუკავშირე.","Link tasks to this goal when creating or editing a task."),fontSize=12.sp)
    }},confirmButton={Button(enabled=name.isNotBlank()&&(target.toIntOrNull() ?: 0)>0,onClick={store.addGoal(PlanGoal(title=name.trim(),target=target.toInt(),category=category));onClose()}){Text(tr("შექმნა","Create"))}},dismissButton={TextButton(onClick=onClose){Text(tr("გაუქმება","Cancel"))}})
}
